export { default as ClientsPage } from "./ClientsPage";
export { default as MaterialsPage } from "./MaterialsPage";
export { default as InksPage } from "./InksPage";
export { default as ServicesPage } from "./ServicesPage";
export { default as ReportsPage } from "./ReportsPage";
export { default as PlansPage } from "./PlansPage";
export { default as SettingsPage } from "./SettingsPage";